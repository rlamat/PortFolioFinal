USE S1B_KerchaouiLamatVersionF
/* Script de remplissage de la base de donn�e */

/* On remplit APPELLATION_VITICOLE */
INSERT INTO APPELLATION_VITICOLE (NOMAPPELLATION) VALUES ('M�doc'),('Saint-Est�phe'),('Pauillac'),('Saint-Julien'),('Listrac-M�doc'),('Moulis'),('Margaux'),('Pessac-L�ognan'),('C�rons'),('Barsac'),('Sauternes'),('Premi�res-C�tes-deBordeaux'),('Graves-de-Vayres')
INSERT INTO APPELLATION_VITICOLE VALUES ('Sainte-Foy-Bordeaux'),('C�tes-de-Bordeaux-Saint-Macaire'),('Sainte-Croix-du-Mont'),('Loupiac'),('Cadillac'),('C�tes-de-Bordeaux Cadillac'),('Entre-deux-Mers Haut Benauge')
INSERT INTO APPELLATION_VITICOLE VALUES ('Premi�res-C�tes-de-Bordeaux'),('Canon-Fronsac'),('Fronsac'),('Neac')
INSERT INTO APPELLATION_VITICOLE VALUES ('Lalande-de-Pomerol'),('Pomerol'),('Saint-�milion')
INSERT INTO APPELLATION_VITICOLE VALUES ('Saint-�milion Grand Cru')
INSERT INTO APPELLATION_VITICOLE VALUES ('Saint-�milion grand cru Grand Cru class�')
INSERT INTO APPELLATION_VITICOLE VALUES ('Saint-�milion grand cru Premier grand cru class�'),('Lussac-Saint-�milion'),('Montagne-Saint-�milion'),('Puisseguin-Saint-�milion'),('Saint-Georges-Saint-�milion'),('C�tes-de-Bordeaux-Franc'),('C�tes-de-Bordeaux-Castillon')
INSERT INTO APPELLATION_VITICOLE VALUES ('Blaye'),('C�tes de Bourg, Bourg et Bourgeais'),('C�tes-de-Blaye')
/* Fin de remplissage */

/* On remplit MILL�SIME */
INSERT INTO MILL�SIME VALUES ('2014-07-09'),('2017-07-08'),('2014-08-03'),('2002-07-05'),('2019-08-05'),('2006-08-02'),('2014-07-09'),('2014-07-07'),('2014-07-03'),('2014-07-01'),('2014-08-05'),('2014-08-02')
/* Fin de remplissage */

/* On remplit la table CLASSEMENT */
INSERT INTO CLASSEMENT VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(14),(15),(99)
/* Fin de remplissage */

/* On remplit la table VILLE */
INSERT INTO VILLE VALUES ('Pessac'), ('Bordeaux'), ('Leognan'), ('Blaye'), ('Gradignan'), ('Cestas'), ('Cadillac'), ('Pauillac'), ('Arcachon'), ('Talence')
/* Fin de remplissage */

/* On remplit la table CHATEAU */
INSERT INTO CHATEAU (NOMCHATEAU,ADRESSE,NUMTELCHATEAU,COORDONNEESBANCAIRES,TELCONTACT,NOMCONTACT,CODEVILLE) VALUES ('Chateau Venus','3 Pertigues Lieu dit Brouquet',0603179139,1487568475, 0682934049,'Laurent De La Ronde',2)
INSERT INTO CHATEAU (NOMCHATEAU,ADRESSE,NUMTELCHATEAU,COORDONNEESBANCAIRES,TELCONTACT,NOMCONTACT,CODEVILLE) VALUES ('Ch�teau Pape Cl�ment','216 Avenue Docteur Nancel Penard',0557265865,1297645768,0637847548,'Bernard Magrez',1)
INSERT INTO CHATEAU (NOMCHATEAU,ADRESSE,NUMTELCHATEAU,COORDONNEESBANCAIRES,TELCONTACT,NOMCONTACT,CODEVILLE) VALUES ('Ch�teau Haut-Brion','135 avenue Jean Jaur�s',0500265865,1297645700,0537847548,'Clarence Dillon',1)
/* Fin de remplissage */

/* On remplit la table VIN */
INSERT INTO VIN(CLEVIN,CLEAPPELLATION,CODEMILLESIME,CLECHATEAU,NUMCLASSEMENT,NOMVIN,QUANTITE,COULEUR,PRIXINITIAL) VALUES (1,30,8,3,3,'CH�TEAU HAUT-BRION 1er Grand Cru Class�',13,'Rouge',750)
INSERT INTO VIN(CLEVIN,CLEAPPELLATION,CODEMILLESIME,CLECHATEAU,NUMCLASSEMENT,NOMVIN,QUANTITE,COULEUR,PRIXINITIAL) VALUES (2,1,1,1,15,'Rimauresq Rebelle',27,'Ros�',18)
INSERT INTO VIN(CLEVIN,CLEAPPELLATION,CODEMILLESIME,CLECHATEAU,NUMCLASSEMENT,NOMVIN,QUANTITE,COULEUR,PRIXINITIAL) VALUES (3,8,6,2,6,'CH�TEAU PAPE CL�MENT 2016 Grand Cru Class�',6,'Rouge',680)
/* Fin de remplissage */

/* On remplit la table COMMANDE */
INSERT INTO  COMMANDE (DATE) VALUES ('2021-02-01'),('2022-01-01'),('2021-07-09')
/* Fin de remplissage */

/* On remplit la table CONTIENT */
INSERT INTO CONTIENT(CLEVIN, NUMCOMMANDE, NBBOUTEILLE) VALUES (1,1,3),(3,2,5),(2,3,11)
/* Din de remplissage */
 
/* On remplit la table CONTIENT */
INSERT INTO ACHAT (CLECHATEAU,NUMCOMMANDE,QUANTITEACHETEE,PRIX) VALUES (3,2,2,700),(1,3,8,15),(2,1,3,600)
/* Din de remplissage */


select * from APPELLATION_VITICOLE
select * from MILL�SIME
select * from CLASSEMENT
select * from ville
select * from CHATEAU
select * from VIN
select * from COMMANDE
select * from CONTIENT
select * from ACHAT
